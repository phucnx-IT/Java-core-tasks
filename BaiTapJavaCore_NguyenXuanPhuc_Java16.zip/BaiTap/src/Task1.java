
public class Task1 {
	public static void div1() {

		for (int i = 0; i < 6; i++) {
			System.out.print("* ");
		}
		for (int i = 0; i < 38; i++) {
			System.out.print("=");
		}
		System.out.println();
	}

	public static void div2() {
		for (int i = 0; i < 5; i++) {
			System.out.print(" *");
		}
		System.out.print("  ");
		for (int i = 0; i < 38; i++) {
			System.out.print("=");
		}
		System.out.println();
	}

	public static void div3() {
		for (int i = 0; i < 50; i++) {
			System.out.print("=");
		}
		System.out.println();
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		for (int i = 0; i < 4; i++) {
			div1();
			div2();
		}
		div1();
		for (int i = 0; i < 6; i++) {
			div3();
		}

	}

}