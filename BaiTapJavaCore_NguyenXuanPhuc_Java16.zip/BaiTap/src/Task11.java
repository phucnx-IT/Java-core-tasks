import java.util.Scanner;

public class Task11 {
	public static void logarithmOfNumber(Scanner scan) {
		int n;
		do {
			System.out.print("Please input a number greater than 0: ");
			n = Integer.parseInt(scan.nextLine());
		} while (n <= 0);
		float value = Math.round((Math.log10(n) / Math.log10(2)) * 100) / 100f;
		System.out.println("Value of log2(" + n + ") is: " + value);
		if (value > Math.floor(value)) {
			System.out.println("The largest number which less than log2(" + n + ") is: " + Math.floor(value));
		} else if (value == 0) {
			System.out.println("The largest number which less than log2(" + n + ") is: " + value);
		} else {
			System.out.println("The largest number which less than log2(" + n + ") is: " + (value - 1));
		}
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner scan = new Scanner(System.in);
		logarithmOfNumber(scan);
	}

}
