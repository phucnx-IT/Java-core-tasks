import java.util.Scanner;

public class Task12 {
	public static void outputTriangleWithInputNumber(Scanner scan) {
		int n;
		do {
			System.out.print("Please enter a number greater than 0: ");
			n = Integer.parseInt(scan.nextLine());
		} while (n < 0);
		for (int i = 1; i <= n; i++) {
			for (int j = 1; j <= i; j++) {
				System.out.print(j);
			}
			System.out.println();
		}
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner scan = new Scanner(System.in);
		outputTriangleWithInputNumber(scan);
	}

}
