import java.util.Scanner;

public class Task13 {
	public static int inputIndexOfArray(Scanner scan) {
		int n;
		do {
			System.out.print("Please enter the number of index greater than zero: ");
			n = Integer.parseInt(scan.nextLine());
		} while (n < 0);
		return n;
	}

	public static int[] inputValueOfArray(int n, Scanner scan) {
		int arr[] = new int[n];
		System.out.println("Please input the value of array: ");
		for (int i = 0; i < arr.length; i++) {
			System.out.print("arr[" + i + "]= ");
			arr[i] = Integer.parseInt(scan.nextLine());
		}
		return arr;
	}

	public static void average(int a[]) {
		float average = 0;
		int i = 0;
		for (int value : a) {
			average += value;
			i++;
		}
		System.out.println("Average of array are: " + Math.round((average / i) * 100) / 100f);
	}

	public static void maxAndMinValue(int a[]) {
		int max = 0;
		int min = 0;
		for (int i = 0; i < a.length; i++) {
			if (a[i] > a[max]) {
				max = i;
			}
			if (a[i] < a[min]) {
				min = i;
			}
		}
		System.out.println("Max value of array are: " + a[max]);
		System.out.println("Min value of array are: " + a[min]);
	}

	public static void maxAndMinOfNegativeValue(int a[]) {
		int index = -1;
		for (int i = 0; i < a.length; i++) {
			if (a[i] < 0) {
				index = i;
				break;
			}
		}
		if (index != -1) {
			int max = index;
			int min = index;
			for (int i = index; i < a.length; i++) {
				if (a[i] < 0) {
					if (a[i] > a[max]) {
						max = i;
					}
					if (a[i] < a[min]) {
						min = i;
					}
				}
			}
			System.out.println("Max negative value of array are: " + a[max]);
			System.out.println("Min negative value of array are: " + a[min]);
		} else {
			System.out.println("Can't find any negative values array");
		}
	}

	public static void maxAndMinOfPositiveValue(int a[]) {
		int index = -1;
		for (int i = 0; i < a.length; i++) {
			if (a[i] > 0) {
				index = i;
				break;
			}
		}
		if (index != -1) {
			int max = index;
			int min = index;
			for (int i = index; i < a.length; i++) {
				if (a[i] > 0) {
					if (a[i] > a[max]) {
						max = i;
					}
					if (a[i] < a[min]) {
						min = i;
					}
				}
			}
			System.out.println("Max positive value of array are: " + a[max]);
			System.out.println("Min positive value of array are: " + a[min]);
		} else {
			System.out.println("Can't find any positive values array");
		}
	}

	public static void oddAndEvenValue(int a[]) {
		System.out.print("Even value: ");
		for (int value : a) {
			if (value % 2 == 0) {
				System.out.print(value + " ");
			}
		}
		System.out.println();
		System.out.print("Odd value: ");
		for (int value : a) {
			if (value % 2 != 0) {
				System.out.print(value + " ");
			}
		}
		System.out.println();
	}

	public static int[] addIndex(int a[], Scanner scan) {
		int arr[] = new int[a.length + 1];
		int index;
		do {
			System.out.print("Please enter position of index need to add from 0 to " + (a.length - 1) + ": ");
			index = Byte.parseByte(scan.nextLine());
		} while (index < 0 || index > a.length - 1);
		for (int i = 0, j = 0; i < arr.length; i++) {
			if (i == index) {
				System.out.print("Please enter value of index need to add: ");
				arr[i] = Integer.parseInt(scan.nextLine());
			} else
				arr[i] = a[j++];
		}
		System.out.print("Values of array after added: ");
		for (int value : arr) {
			System.out.print(value + " ");
		}
		System.out.println();
		a = arr;
		return a;
	}

	public static void removeIndex(int a[], Scanner scan) {
		int arr[] = new int[a.length - 1];
		int index;
		do {
			System.out.print("Please enter position of index need to remove from 0 to " + (a.length - 1) + ": ");
			index = Byte.parseByte(scan.nextLine());
		} while (index < 0 || index > a.length - 1);
		for (int i = 0, j = 0; i < arr.length; i++) {
			if (i < index) {
				arr[i] = a[j++];
			} else if (i >= index) {
				arr[i] = a[++j];
			}
		}
		System.out.print("Values of array after remove: ");
		for (int value : arr) {
			System.out.print(value + " ");
		}
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner scan = new Scanner(System.in);
		int n = inputIndexOfArray(scan);
		int arr[] = inputValueOfArray(n, scan);
		String line = "===============================================================================";
		average(arr);
		System.out.println(line);
		maxAndMinValue(arr);
		System.out.println(line);
		maxAndMinOfNegativeValue(arr);
		System.out.println(line);
		maxAndMinOfPositiveValue(arr);
		System.out.println(line);
		oddAndEvenValue(arr);
		System.out.println(line);
		arr = addIndex(arr, scan);
		System.out.println(line);
		removeIndex(arr, scan);
	}

}
