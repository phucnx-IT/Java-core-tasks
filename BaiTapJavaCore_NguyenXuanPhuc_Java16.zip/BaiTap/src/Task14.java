import java.util.Scanner;

public class Task14 {
	public static int[] inputArray(Scanner scan) {
		int n;
		do {
			System.out.print("Please enter the number of index: ");
			n = Integer.parseInt(scan.nextLine());
		} while (n < 0);
		int arr[] = new int[n];
		for (int i = 0; i < arr.length; i++) {
			System.out.print("arr[" + i + "]= ");
			arr[i] = Integer.parseInt(scan.nextLine());
		}
		return arr;
	}

	public static void removeDoubleValue(int a[]) {

		byte count = 0;
		for (int i = 0; i < a.length; i++) {
			for (int j = i; j < a.length; j++) {
				if (j > i && a[j] == a[i] && a[j] != 0) {
					a[j] = 0;
					count++;
				}
			}
		}
		int arr[] = new int[a.length - count];
		for (int i = 0, j = 0; i < a.length; i++) {
			if (a[i] != 0) {
				arr[j++] = a[i];
			}
		}
		System.out.print("Values of array after remove double values: ");
		for (int value : arr) {
			System.out.print(value + " ");
		}
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner scan = new Scanner(System.in);
		int arr[] = inputArray(scan);
		removeDoubleValue(arr);
	}

}
