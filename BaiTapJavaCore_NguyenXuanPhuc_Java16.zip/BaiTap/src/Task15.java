import java.util.Scanner;

public class Task15 {
	public static String inputStringAndOutputCharAtIndex(Scanner scan) {
		byte n;
		System.out.print("Please input a string: ");
		String text = scan.nextLine();
		System.out.println("The length of string are: " + text.length());
		do {
			System.out.print("Please enter the position which you want to take character from 0 to "
					+ (text.length() - 1) + ": ");
			n = Byte.parseByte(scan.nextLine());
		} while (n < 0 || n > (text.length() - 1));
		System.out.println("The character you want is: " + text.charAt(n));
		return text;
	}

	public static void checkSubstringABCDEF(String text) {
		if (text.contains("abcdef")) {
			System.out.println("The string has substring (abcdef)");
		} else {
			System.out.println("The string hasn't substring (abcdef)");
		}
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner scan = new Scanner(System.in);
		String text = inputStringAndOutputCharAtIndex(scan);
		checkSubstringABCDEF(text);
	}

}
