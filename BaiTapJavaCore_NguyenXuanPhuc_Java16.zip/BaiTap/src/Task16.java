import java.util.Scanner;

public class Task16 {
	public static void checkLeapYear(Scanner scan) {
		System.out.print("Please enter year you want to check: ");
		short n = Short.parseShort(scan.nextLine());
		if (n % 400 == 0) {
			System.out.println(n + " is leap year");
		} else {
			System.out.println(n + " non leap year");
		}
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner scan = new Scanner(System.in);
		checkLeapYear(scan);
	}

}
