import java.util.Scanner;

public class Task17 {
	public static void guessNumber(Scanner scan) {
		System.out.println("We have secret number from 1 to 1000");
		short random = (short) (Math.random() * 1001);
		short inputNumber;
		do {
			System.out.print("Please enter any number to guess which secret number is: ");
			inputNumber = Short.parseShort(scan.nextLine());
			if (inputNumber > random) {
				System.out.println("********The number you input GREATER than secret number**********");
			} else if(inputNumber < random){
				System.out.println("********The number you input LESS than secret number**********");
			}
		} while (inputNumber != random);
		System.out.println("Congratulation, you right !!!!!");
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner scan = new Scanner(System.in);
		guessNumber(scan);

	}

}
