import java.util.Scanner;

public class Task18 {
	public static void waitingYears(Scanner scan) {
		System.out.print("Please enter X's deposit (millions): ");
		float deposit = Short.parseShort(scan.nextLine());
		System.out.print("Please enter money he wants to get (millions) : ");
		short interest = Short.parseShort(scan.nextLine());
		System.out.print("Please enter interest rate for year (%): ");
		float rate = Float.parseFloat(scan.nextLine());
		short yearWaiting = 0;
		do {
			deposit += deposit * (1.0f) * rate;
			yearWaiting++;
		} while (interest > deposit);
		System.out.println("Years for waiting are: " + yearWaiting);
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner scan = new Scanner(System.in);
		waitingYears(scan);
	}

}
