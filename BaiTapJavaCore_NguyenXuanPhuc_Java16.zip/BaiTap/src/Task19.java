import java.util.Scanner;

public class Task19 {
	public static void doMenu(Scanner scan) {
		boolean flag = true;
		do {
			System.out.println("1. Solve first degree equation");
			System.out.println("2. Solve first degree equation");
			System.out.println("0. Exit");
			System.out.print("Please pick number: ");
			byte pick = Byte.parseByte(scan.nextLine());
			switch (pick) {
			case 1:
				firstDegreeEquation(scan);
				break;
			case 2:
				secondDegreeEquation(scan);
				break;
			case 0:
				flag = false;
				break;
			default:
				System.out.println("Please pick number from 0 to 2");
			}
		} while (flag);
	}
public static void firstDegreeEquation(Scanner scan) {
	System.out.print("Please enter a value: ");
	short a=Short.parseShort(scan.nextLine());
	System.out.print("Please enter b value: ");
	short b=Short.parseShort(scan.nextLine());
	System.out.println("We have equation: "+a+"x + ("+b+") = "+0);
	System.out.println("The solution of equation are: x= "+Math.round((-b*(1.0f)/a)*100)/100f);
	System.out.println("=========================================");
}
public static void secondDegreeEquation(Scanner scan) {
	System.out.print("Please enter a value: ");
	short a=Short.parseShort(scan.nextLine());
	System.out.print("Please enter b value: ");
	short b=Short.parseShort(scan.nextLine());
	System.out.print("Please enter b value: ");
	short c=Short.parseShort(scan.nextLine());
	System.out.println("We have equation: "+a+"x^2 + ("+b+"x) + ("+c+") = "+0);
	float denta=0;
	denta=(float) (Math.pow(b, 2)-4*a*c);
	if(denta>0) {
		System.out.println("We have 2 solutions");
		System.out.println("The solution of equation are: x1= "+Math.round(((-b+Math.sqrt(denta))*(1.0f)/(2*a))*100)/100f);
		System.out.println("The solution of equation are: x2= "+Math.round(((-b-Math.sqrt(denta))*(1.0f)/(2*a))*100)/100f);
	}else if(denta==0) {
		System.out.println("The solution of equation are: x1=x2= "+Math.round((-b*(1.0f)/(2*a))*100)/100f);
	}else {
		System.out.println("Impossible equation");
	}
	System.out.println("=========================================");
}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner scan = new Scanner(System.in);
		doMenu(scan);
	}

}
