import java.util.Scanner;

public class Task2 {
//public static void decimalToBinary(Scanner scan) {
//	System.out.print("Please input decimal number: ");
//	int decimalNumber=Integer.parseInt(scan.nextLine());
//	System.out.println("Binary of "+decimalNumber+" is: "+Integer.toBinaryString(decimalNumber));
//}
	public static void decimalToBinary(Scanner scan) {
		System.out.print("Please input decimal number: ");
		int decimalNumber = Integer.parseInt(scan.nextLine());
		int temp = decimalNumber;
		String text = "";
		do {
			if (temp % 2 != 0) {
				text += "1";
			} else {
				text += "0";
			}
			temp /= 2;
		} while (temp > 0);
		String resever = new StringBuffer(text).reverse().toString();
		System.out.println("Binary of " + decimalNumber + " is: " + resever);
	}

	public static void binaryToDecimal(Scanner scan) {
		System.out.print("Please input binary number: ");
		int binaryNumber = Integer.parseInt(scan.nextLine());
		int count = 0;
		int temp = binaryNumber;
		int decimalNumber = 0;
		do {
			int lastOfNumber = temp % 10;
			decimalNumber += lastOfNumber * Math.pow(2, count++);
			temp /= 10;	
		} while (temp > 0);
		System.out.println("Decimal of " + binaryNumber + " is: " + decimalNumber);
	}

	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		decimalToBinary(scan);
		binaryToDecimal(scan);

	}

}
