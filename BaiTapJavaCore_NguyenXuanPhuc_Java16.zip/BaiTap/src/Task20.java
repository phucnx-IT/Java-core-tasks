import java.util.Scanner;

public class Task20 {
	public static int[] inputArray(Scanner scan) {
		int n;
		do {
			System.out.print("Please enter the number of index: ");
			n = Integer.parseInt(scan.nextLine());
		} while (n < 0);
		int arr[] = new int[n];
		for (int i = 0; i < arr.length; i++) {
			System.out.print("arr[" + i + "]= ");
			arr[i] = Integer.parseInt(scan.nextLine());
		}
		return arr;
	}

	public static void seperateArray(int a[]) {
		short countEvenValue = 0;
		short countOddValue = 0;
		for (int value : a) {
			if (value % 2 == 0) {
				countEvenValue++;
			} else {
				countOddValue++;
			}
		}
		int even[] = new int[countEvenValue];
		int odd[] = new int[countOddValue];
		for (int i = 0, j = 0, k = 0; i < a.length; i++) {
			if (a[i] % 2 == 0) {
				even[j++] = a[i];
			} else {
				odd[k++] = a[i];
			}
		}
		if (countEvenValue > 0) {
			System.out.print("Even array include: ");
			for (int value : even) {
				System.out.print(value + " ");
			}
		} else {
			System.out.print("Non even value in array");
		}
		if (countOddValue > 0) {
			System.out.print("\nOdd array include: ");
			for (int value : odd) {
				System.out.print(value + " ");
			}
		} else {
			System.out.print("\nNon odd value in array");
		}
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner scan = new Scanner(System.in);
		int arr[] = inputArray(scan);
		seperateArray(arr);
	}

}
