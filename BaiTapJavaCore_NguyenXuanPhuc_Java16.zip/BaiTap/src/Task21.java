import java.util.Scanner;

public class Task21 {
	public static void findPositionOfTwoKan(Scanner scan) {
		short x1, x2;
		short v1, v2;
		do {
			System.out.print("Please enter position of Kan1 (0-10000): ");
			x1 = Short.parseShort(scan.nextLine());
			System.out.print("Please enter position of Kan2 (0-10000): ");
			x2 = Short.parseShort(scan.nextLine());
		} while (x1 < 0 || x1 > 10000 || x2 < 0 || x2 > 10000);
		do {
			System.out.print("Please enter speed of Kan1 (1-10000): ");
			v1 = Short.parseShort(scan.nextLine());
			System.out.print("Please enter speed of Kan2 (1-10000): ");
			v2 = Short.parseShort(scan.nextLine());
		} while (v1 < 1 || v1 > 10000 || v2 < 1 || v2 > 10000);
		do {
			x1 += v1;
			x2 += v2;
		} while (x1 != x2 && x1 < 10000 && x2 < 10000);
		if (x1 == x2) {
			System.out.println("Two Kans have met at x1=x2= " + x1);
		} else {
			System.out.println("Two Kans haven't met");
		}
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner scan = new Scanner(System.in);
		findPositionOfTwoKan(scan);

	}

}
