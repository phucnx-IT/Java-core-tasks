import java.util.Scanner;

public class Task22 {
	public static void checkString(Scanner scan) {
		System.out.print("Please input a text: ");
		String text = scan.nextLine();
		String[] subString = text.split(" ");
		byte max = 0;
		int indexOfText = 0;
		for (int i = 0; i < subString.length; i++) {
			byte count = 0;
			for (int j = 0; j < subString[i].length() / 2; j++) {
				if (subString[i].charAt(j) == subString[i].charAt(subString[i].length() - 1 - j)) {
					count++;
				}
			}
			if (count > max) {
				max = count;
				indexOfText = i;
			}
		}
		if (max == 0) {
			System.out.println("There are no Palindromic in this string");
		} else {
			System.out.println("The longest Palindromic is: " + subString[indexOfText]);
		}
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner scan = new Scanner(System.in);
		checkString(scan);
	}

}
