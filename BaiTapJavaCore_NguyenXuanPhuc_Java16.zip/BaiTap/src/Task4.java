import java.util.Scanner;

public class Task4 {
	public static void sumOfDigits(int n) {
		int sum = 0;
		int temp=n;
		while (temp > 0) {
			int digits = temp % 10;
			sum += digits;
			temp /= 10;
		}
		System.out.println("The sum of " + n + " là: " + sum);
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner scan = new Scanner(System.in);
		System.out.print("Please enter number: ");
		int n = Integer.parseInt(scan.nextLine());
		sumOfDigits(n);
	}

}
