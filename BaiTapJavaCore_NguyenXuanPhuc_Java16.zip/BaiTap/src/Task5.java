import java.util.Scanner;

public class Task5 {
	public static void calculateABDistance(Scanner scan) {
		System.out.println("Nhập vào tọa độ điểm A: ");
		System.out.print("x1= ");
		short x1 = Short.parseShort(scan.nextLine());
		System.out.print("y1= ");
		short y1 = Short.parseShort(scan.nextLine());
		System.out.println("Nhập vào tọa độ điểm B: ");
		System.out.print("x2= ");
		short x2 = Short.parseShort(scan.nextLine());
		System.out.print("y2= ");
		short y2 = Short.parseShort(scan.nextLine());
		float distance=(float) Math.round(Math.sqrt(Math.pow(x2-x1, 2)+Math.pow(y2-y1, 2))*100)/100;
		System.out.println("The distance between A and B is: "+distance);
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner scan = new Scanner(System.in);
		calculateABDistance(scan);
	}

}
