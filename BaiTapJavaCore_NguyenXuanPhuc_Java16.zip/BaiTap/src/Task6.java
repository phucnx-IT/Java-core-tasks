import java.util.Scanner;

public class Task6 {
	public static void stringReverse(Scanner scan) {
		System.out.print("Please enter strings of character: ");
		String text = scan.nextLine();
		String reverse = new StringBuffer(text).reverse().toString();
		System.out.println("The string reverse is: " + reverse);
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner scan = new Scanner(System.in);
		stringReverse(scan);
	}

}
