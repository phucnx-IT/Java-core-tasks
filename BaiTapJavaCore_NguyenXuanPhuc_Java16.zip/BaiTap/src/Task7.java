import java.util.Scanner;

public class Task7 {
	public static void divisorNumber(Scanner scan) {
		System.out.print("Please enter a number: ");
		int inputNum = Integer.parseInt(scan.nextLine());
		System.out.print("Divisor of " + inputNum + " are: ");
		for (int i = inputNum; i > 0; i--) {
			if (inputNum % i == 0) {
				System.out.print(i + " ");
			}
		}
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner scan = new Scanner(System.in);
		divisorNumber(scan);
	}

}
