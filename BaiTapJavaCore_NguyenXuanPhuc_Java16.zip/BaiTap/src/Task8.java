import java.util.Scanner;

public class Task8 {
	public static void inputString(Scanner scan) {
		System.out.print("Please enter a lowercase string: ");
		String text = scan.nextLine();
		String[] temp = text.split(" ");
		String uppercaseString = "";
		System.out.print("String capitalize first letter: ");
		for (int i = 0; i < temp.length; i++) {
			uppercaseString = temp[i].substring(0, 1).toUpperCase() + temp[i].substring(1);
			System.out.print(uppercaseString + " ");
		}

	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner scan = new Scanner(System.in);
		inputString(scan);
	}

}
