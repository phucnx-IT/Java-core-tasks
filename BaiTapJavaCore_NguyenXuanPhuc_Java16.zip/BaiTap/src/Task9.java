import java.util.Scanner;

public class Task9 {
	public static void checkNumber(Scanner scan) {
		byte inputNumber1, inputNumber2;
		do {
			System.out.print("Please enter number1 from 10 to 99: ");
			inputNumber1 = Byte.parseByte(scan.nextLine());
		} while (inputNumber1 < 10 || inputNumber1 > 99);
		do {
			System.out.print("Please enter number2 from 10 to 99: ");
			inputNumber2 = Byte.parseByte(scan.nextLine());
		} while (inputNumber2 < 10 || inputNumber2 > 99);
		if (String.valueOf(inputNumber1).contains(String.valueOf(inputNumber2 / 10))
				|| String.valueOf(inputNumber1).contains(String.valueOf(inputNumber2 % 10))) {
			System.out.println("TRUE");
		} else {
			System.out.println("FALSE");
		}
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner scan = new Scanner(System.in);
		checkNumber(scan);
	}

}
